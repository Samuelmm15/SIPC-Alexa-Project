module.exports = {
    '0' : {
        'id' : '0',
        'release' : 'Monster Gallo Loco',
        'date' : '15 de enero de 202315 de enero de 2023',
        'last': false
    },
    '1' : {
        'id' : '1',
        'release' : 'Platano Palmero',
        'date' : '15 de enero de 2023',
        'last': false
    },
    '2' : {
        'id' : '2',
        'release' : 'Pollo asado de Timanfaya',
        'date' : '15 de enero de 2023',
        'last': false
    },
    '3' : {
        'id' : '3',
        'release' : 'Cliper de Guayaba',
        'date' : '15 de enero de 2023',
        'last': true
    },
};