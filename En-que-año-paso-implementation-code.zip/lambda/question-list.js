module.exports = {
  '0' : {
        'id' : '0',
        'question' : 'Ivan',
        'year' : '1963',
        'answer' : 'PRUEBA',
        'clue' : 'PRUEBA'
  },
  '1' : {
        'id' : '1',
        'question' : 'Douglas',
        'year' : '1963',
        'answer' : 'PRUEBA',
        'clue' : 'PRUEBA'
  },
  '2' : {
        'id' : '2',
        'question' : 'MIT',
        'year' : '1968',
        'answer' : 'PRUEBA',
        'clue' : 'PRUEBA'
  },
  '3' : {
        'id' : '3',
        'question' : 'XEROX',
        'year' : '1981',
        'answer' : 'PRUEBA',
        'clue' : 'PRUEBA'
  }
};